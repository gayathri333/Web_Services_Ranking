****************************************************************************
* README file for Uploads folder in WS_Ranking.py
* Last updated: 2021/04/26
****************************************************************************

Contents of the uploaded .xlsx files(One Web Service):
1)The first two columns in the first row should have the headings Response Time and Thoughput respectively.
2)The following 100 rows should have the corresponding response time and throughput values of 100 different users of that web service.